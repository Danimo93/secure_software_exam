# test_app.py
import unittest
from models import User
from api_controller import protected_resource
from file_controller import upload_file
from flask import Flask
from io import BytesIO

app = Flask(__name__)

class TestAuthentication(unittest.TestCase):
    def setUp(self):
        self.user = User(username="testuser", password_hash="hashedpassword")
        self.token = "valid_token"
        self.invalid_token = "invalid_token"

    def test_login_with_valid_credentials(self):
        response = self.user.authenticate("testuser", "password")
        self.assertTrue(response, "Authentication with valid credentials should succeed")

    def test_login_with_invalid_credentials(self):
        response = self.user.authenticate("testuser", "wrongpassword")
        self.assertFalse(response, "Authentication with invalid credentials should fail")

    def test_protected_resource_with_valid_token(self):
        with app.test_request_context(headers={"Authorization": self.token}):
            response = protected_resource()
            self.assertEqual(response[1], 200, "Should allow access with valid token")

    def test_protected_resource_with_invalid_token(self):
        with app.test_request_context(headers={"Authorization": self.invalid_token}):
            response = protected_resource()
            self.assertEqual(response[1], 403, "Should deny access with invalid token")


class TestFileUpload(unittest.TestCase):
    def setUp(self):
        self.user = User(username="testuser", password_hash="hashedpassword")
        self.file_content = b"Test file content"
        self.file_name = "testfile.txt"

    def test_file_upload(self):
        with app.test_request_context(method="POST", data={
            "file": (BytesIO(self.file_content), self.file_name)
        }, content_type="multipart/form-data"):
            response = upload_file(self.user)
            self.assertEqual(response[1], 200, "File upload should succeed")
            self.assertIn(self.file_name, response[0].json["message"], "File name should be in success message")


if __name__ == '__main__':
    unittest.main()
