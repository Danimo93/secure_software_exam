# app/file_controller.py

import os
from flask import request, redirect, flash, render_template, url_for
from werkzeug.utils import secure_filename
from flask_login import login_required, current_user  # Make sure Flask-Login is being used
from app.models import File

UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Upload a file (Only accessible to authenticated users)
@login_required
def upload_file():
    if request.method == 'POST':
        # Check if a file is in the request
        if 'file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)

        file = request.files['file']
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)

        if file and allowed_file(file.filename):
            # Secure the filename and save the file
            filename = secure_filename(file.filename)
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)

            # Save file metadata to the database
            new_file = File(user_id=current_user.id, filename=filename, filepath=filepath)
            new_file.save()

            flash('File uploaded successfully', 'success')
            return redirect(url_for('upload_file'))

    return render_template('upload.html')
