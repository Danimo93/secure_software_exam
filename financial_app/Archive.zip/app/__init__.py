from flask import Flask, render_template
from flask_login import LoginManager
from app.auth_controller import register_user, login_user_view, request_password_reset, reset_password, logout
from app.api_controller import protected_resource
from app.models import User

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Flask-Login Setup
login_manager = LoginManager()
login_manager.init_app(app)

# User loader for Flask-Login (loads user by their ID for session management)
@login_manager.user_loader
def load_user(user_id):
    return User.find_by_id(user_id)

# Define routes
@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register_user_route():
    return register_user()

@app.route('/login', methods=['GET', 'POST'])
def login_user_route():
    return login_user_view()

@app.route('/logout', methods=['GET'])
def logout_route():
    return logout()

@app.route('/request-reset', methods=['GET', 'POST'])
def request_password_reset_route():
    return request_password_reset()

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password_route(token):
    return reset_password(token)

# Secure API route that requires token authentication
@app.route('/api/protected', methods=['GET'])
def protected_resource_route():
    return protected_resource()
