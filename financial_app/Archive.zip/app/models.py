import sqlite3
from datetime import datetime
from app.db_setup import connect_db

class User:
    def __init__(self, id, username, password_hash, email, api_token=None, api_token_expiry=None, reset_token=None, token_expiry=None):
        self.id = id
        self.username = username
        self.password_hash = password_hash
        self.email = email
        self.api_token = api_token
        self.api_token_expiry = api_token_expiry
        self.reset_token = reset_token
        self.token_expiry = token_expiry

    # Create a new user in the database
    @staticmethod
    def create_user(username, email, password_hash):
        try:
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)", 
                           (username, email, password_hash))
            conn.commit()
            conn.close()  # Ensure database connection is closed to avoid locks
            return True
        except sqlite3.IntegrityError:
            return False

    # Find a user by username
    @staticmethod
    def find_by_username(username):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        result = cursor.fetchone()
        conn.close()  # Ensure database connection is closed to avoid locks
        if result:
            return User(*result)  # Pass all fields to the User class
        return None

    # Find a user by their ID (used by Flask-Login)
    @staticmethod
    def find_by_id(user_id):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id=?", (user_id,))
        result = cursor.fetchone()
        conn.close()  # Ensure database connection is closed to avoid locks
        if result:
            return User(*result)
        return None

    @property
    def is_authenticated(self):
        return True  # Since we are using session-based login

    @property
    def is_active(self):
        return True  # For now, all users are active

    @property
    def is_anonymous(self):
        return False  # We are not allowing anonymous users

    def get_id(self):
        return str(self.id)

    # Update the user's API token and its expiry time
    def update_token(self, token, expiry_time):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET api_token=?, api_token_expiry=? WHERE id=?", 
                       (token, expiry_time, self.id))
        conn.commit()
        conn.close()  # Ensure database connection is closed to avoid locks

    # Clear the user's API token and its expiry time
    def clear_token(self):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET api_token=NULL, api_token_expiry=NULL WHERE id=?", 
                       (self.id,))
        conn.commit()
        conn.close()

    # Update the user's password
    def update_password(self, new_password_hash):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET password_hash=? WHERE id=?", 
                       (new_password_hash, self.id))
        conn.commit()
        conn.close()

    # Find a user by email or username for password reset
    @staticmethod
    def find_by_email_or_username(email_or_username):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=? OR email=?", (email_or_username, email_or_username))
        result = cursor.fetchone()
        conn.close()
        if result:
            return User(*result)  # Pass all fields to the User class
        return None

    # Update the user's password reset token and its expiry time
    def update_reset_token(self, reset_token, expiry_time):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET reset_token=?, token_expiry=? WHERE id=?", 
                       (reset_token, expiry_time, self.id))
        conn.commit()
        conn.close()

    # Clear the password reset token
    def clear_reset_token(self):
        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET reset_token=NULL, token_expiry=NULL WHERE id=?", 
                       (self.id,))
        conn.commit()
        conn.close()
