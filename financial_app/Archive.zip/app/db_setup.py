import sqlite3

# Function to connect to the database
def connect_db():
    return sqlite3.connect('users.db')

def create_tables():
    conn = connect_db()
    cursor = conn.cursor()

    # Create users table if not exists
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            api_token TEXT,                     -- Add this column for API token authentication
            api_token_expiry TIMESTAMP,         -- Add this column for API token expiry
            reset_token TEXT,                   -- Add this column for password reset tokens
            token_expiry TIMESTAMP              -- Add this column for password reset token expiry
        )
    ''')

    # Create files table if not exists
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            upload_time TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()

# Initialize the database by creating tables
if __name__ == '__main__':
    create_tables()
